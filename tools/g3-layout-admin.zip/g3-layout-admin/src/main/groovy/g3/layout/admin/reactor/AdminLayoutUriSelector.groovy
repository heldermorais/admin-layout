package g3.layout.admin.reactor

import org.slf4j.Logger
import org.slf4j.LoggerFactory

import reactor.bus.selector.UriSelector

class AdminLayoutUriSelector extends UriSelector {

	
	protected static final Logger log = LoggerFactory.getLogger(AdminLayoutUriSelector)
	
	public AdminLayoutUriSelector(){
		super ("app://*@host/path/segment?*")
		//http://*:80/path/segment#fragment
	}
	
	
	public boolean matches(Object key) {
		log.debug "matches - Matching for ${key}"
		boolean resultado = super.matches(key)
		log.debug "matches - ${resultado}"
		return resultado
	}
	
}
