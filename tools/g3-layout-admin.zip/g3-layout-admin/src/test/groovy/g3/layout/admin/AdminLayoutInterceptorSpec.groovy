package g3.layout.admin


import grails.test.mixin.TestFor
import spock.lang.Specification

/**
 * See the API for {@link grails.test.mixin.web.ControllerUnitTestMixin} for usage instructions
 */
@TestFor(AdminLayoutInterceptor)
class AdminLayoutInterceptorSpec extends Specification {

    def setup() {
    }

    def cleanup() {

    }

    void "Test adminLayout interceptor matching"() {
        when:"A request matches the interceptor"
            withRequest(controller:"adminLayout")

        then:"The interceptor does match"
            interceptor.doesMatch()
    }
}
