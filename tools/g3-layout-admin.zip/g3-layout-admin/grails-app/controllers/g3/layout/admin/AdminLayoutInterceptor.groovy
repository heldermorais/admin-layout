package g3.layout.admin

import org.slf4j.Logger
import org.slf4j.LoggerFactory


class AdminLayoutInterceptor {

	protected static final Logger log = LoggerFactory.getLogger(AdminLayoutInterceptor)


	int order = HIGHEST_PRECEDENCE + 100

	ActionDescriptionProcessorService actionDescriptionProcessorService
	
	public AdminLayoutInterceptor(){
		matchAll()
	}


	boolean before() {

		session.admin = [:]

		if (controllerName != null){

			session.admin.actionTitle       = controllerName
			session.admin.actionDescription = actionName
			log.debug "before - ${controllerName}.${actionName}"

			if(actionDescriptionProcessorService != null){
				log.debug "processor != null"
				session.admin << actionDescriptionProcessorService.process(controllerName, actionName)
				log.debug "processor ${session?.admin}"
			}
			
		}

		//model.foo = "bar" // add a new model attribute called 'foo'
		//view = 'alternate' // render a different view called 'alternate'

		true
	}

	boolean after() {
		
		if (controllerName != null){
			if(model == null){
				model = [:]
			}
			model.admin = session?.admin
		}
		
		true
	}

	void afterView() {
		// no-op
	}
}
