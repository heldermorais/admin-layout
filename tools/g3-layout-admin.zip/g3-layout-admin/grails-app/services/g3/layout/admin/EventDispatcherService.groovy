package g3.layout.admin

import javax.annotation.PostConstruct

import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.springframework.boot.context.event.ApplicationStartedEvent

import grails.events.Events
import grails.transaction.Transactional
import reactor.bus.Event
import reactor.spring.context.annotation.Consumer
import reactor.spring.context.annotation.Selector
import reactor.spring.context.annotation.SelectorType

@Transactional
@Consumer
class EventDispatcherService {

	protected static final Logger log = LoggerFactory.getLogger(EventDispatcherService)


	public EventDispatcherService(){
		log.debug "EventDispatcherService created !"
	}


/*	
	@Selector(value="g3.admin:(.+)", type = SelectorType.REGEX)
	void myEventListener1(Event event) {
			log.info "myEventListener1 -  - GOT EVENT data = ${event}"
	}
	
	
	@Selector(value="/adminLte:{controller}/{action}/{resourceId}", type = SelectorType.URI)
	void myEventListener2(Event event) {
			log.info "myEventListener2 -  - GOT EVENT data = ${event}"
	}

	
	@Selector(value="app://*@grailsApp/*", type = SelectorType.URI)
	void myEventListener4(Event event) {
			log.info "myEventListener4 -  - GOT EVENT data = ${event}"
	}
*/	
}
