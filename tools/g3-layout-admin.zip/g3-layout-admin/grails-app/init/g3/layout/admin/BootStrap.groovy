package g3.layout.admin

class BootStrap {

    def init = { servletContext ->
    }
    def destroy = {
    }
}
