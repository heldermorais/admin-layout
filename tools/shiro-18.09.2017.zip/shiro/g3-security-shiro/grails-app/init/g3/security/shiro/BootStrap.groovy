package g3.security.shiro

class BootStrap {

    def init = { servletContext ->
    }
    def destroy = {
    }
}
