package g3.security.shiro

import org.apache.shiro.authc.Account
import org.apache.shiro.authc.AccountException
import org.apache.shiro.authc.AuthenticationException
import org.apache.shiro.authc.AuthenticationInfo
import org.apache.shiro.authc.AuthenticationToken
import org.apache.shiro.authc.SimpleAccount
import org.apache.shiro.authc.UsernamePasswordToken
import org.apache.shiro.authz.Permission
import org.apache.shiro.realm.Realm
import org.apache.shiro.subject.PrincipalCollection
import org.slf4j.LoggerFactory

import grails.transaction.Transactional

@Transactional
class AllowAllRealmService extends AbstractShiroRealm {

	def log = LoggerFactory.getLogger(AllowAllRealmService)


	@Override
	protected Class<? extends AuthenticationToken> getAuthTokenClass() {
		return UsernamePasswordToken;
	}

	@Override
	protected Account authenticate(AuthenticationToken authToken) {
		
		log.debug "Attempting to authenticate ${authToken.username} in DB realm..."
		def username = authToken.username

		// Null username is invalid
		if (username == null) {
			throw new AccountException('Null usernames are not allowed by this realm.')
		}

		
		// Get the user with the given username. If the user is not
		// found, then they don't have an account and we throw an
		// exception.
		/*
		def user = @domain.prefix@User.findByUsername(username)
		if (!user) {
			throw new UnknownAccountException("No account found for user [${username}]")
		}
		*/
		
		
		
		log.debug "Found user '${username}' in DB"

		// Now check the user's password against the hashed value stored
		// in the database.
		def account = new SimpleAccount(username, username, this.getName())
		
		/*
		if (!credentialMatcher.doCredentialsMatch(authToken, account)) {
			log.info 'Invalid password (DB realm)'
			throw new IncorrectCredentialsException("Invalid password for user '${username}'")
		}
		*/
		
		return account
		
	}

	@Override
	public boolean isPermitted(PrincipalCollection subjectPrincipal, String permission) {
		log.debug "isPermitted(${getFirstPrincipal(subjectPrincipal)}, ${permission}) = true"
		
		return true;
	}

	@Override
	public boolean hasRole(PrincipalCollection subjectPrincipal, String roleIdentifier) {
		log.debug "hasRole(${getFirstPrincipal(subjectPrincipal)}, ${roleIdentifier}) = true"
		
		return true;
	}	
	
	
}
