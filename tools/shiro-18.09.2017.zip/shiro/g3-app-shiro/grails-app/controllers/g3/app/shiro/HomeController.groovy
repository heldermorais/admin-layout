package g3.app.shiro

class HomeController {

    def index() { 
		
	}
}
