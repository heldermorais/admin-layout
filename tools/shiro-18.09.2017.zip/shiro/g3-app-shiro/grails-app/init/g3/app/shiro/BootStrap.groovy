package g3.app.shiro

class BootStrap {

    def init = { servletContext ->
    }
    def destroy = {
    }
}
