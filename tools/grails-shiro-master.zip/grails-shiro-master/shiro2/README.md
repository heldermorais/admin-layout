Grails plugin for the Apache Shiro security framework. See the [plugin portal page](http://grails.org/plugin/shiro) for more information.
