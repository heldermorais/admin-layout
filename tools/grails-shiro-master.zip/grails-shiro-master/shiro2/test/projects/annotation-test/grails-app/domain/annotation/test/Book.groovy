package annotation.test

class Book {

    String title
    String author

    static constraints = {
    }
}
