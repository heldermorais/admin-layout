package pages

import geb.Page

class FormListPage extends Page {
    static url = "form/list"

    static at = { title == "Form List" }
}
