class ItemController {
    def scaffold = true
}
