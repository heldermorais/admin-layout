class FormController {
    def scaffold = Form
}
