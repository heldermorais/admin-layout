class Basic {
    String name
    Integer intValue

    static constraints = {
        name()
        intValue()
    }
}
