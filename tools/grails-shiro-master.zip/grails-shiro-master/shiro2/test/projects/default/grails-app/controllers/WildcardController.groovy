class WildcardController {
    def index = { render "Wildcard index page" }
    def one = { render "Wildcard page one" }
    def two = { render "Wildcard page two" }
}
