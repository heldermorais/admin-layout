class BasicController {
    def scaffold = true
}
