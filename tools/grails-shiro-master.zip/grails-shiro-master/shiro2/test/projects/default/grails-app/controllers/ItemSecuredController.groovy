class ItemSecuredController {
    def index = {
        render "Secured item"
    }
}
