class Form {
    String name

    static constraints = {
        name()
    }
}
