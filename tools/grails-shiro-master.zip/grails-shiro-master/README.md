Grails 3 Shiro plugin
=====================

[![Build Status](https://api.travis-ci.org/Arkilog/grails-shiro.png)](http://travis-ci.org/Arkilog/grails-shiro)