package annotation.test

class Book2 {

    String title
    String author

    static constraints = {
    }
}
