reportsDir = "build/geb-reports" 
def url = System.env['geb.build.baseUrl'] ?: "http://localhost:8080/"
baseUrl = url
