package app.lteadmin

class OutroController {

    def index() {


    }
}
