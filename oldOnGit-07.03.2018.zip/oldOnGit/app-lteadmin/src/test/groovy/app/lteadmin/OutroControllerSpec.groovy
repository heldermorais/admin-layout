package app.lteadmin

import grails.testing.web.controllers.ControllerUnitTest
import spock.lang.Specification

class OutroControllerSpec extends Specification implements ControllerUnitTest<OutroController> {

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
