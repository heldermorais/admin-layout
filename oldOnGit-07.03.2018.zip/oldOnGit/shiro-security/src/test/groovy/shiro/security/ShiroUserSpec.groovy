package shiro.security

import grails.testing.gorm.DomainUnitTest
import spock.lang.Specification

class ShiroUserSpec extends Specification implements DomainUnitTest<ShiroUser> {

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
