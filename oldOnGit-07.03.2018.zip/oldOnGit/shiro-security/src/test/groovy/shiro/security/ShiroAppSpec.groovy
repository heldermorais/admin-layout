package shiro.security

import grails.testing.gorm.DomainUnitTest
import spock.lang.Specification

class ShiroAppSpec extends Specification implements DomainUnitTest<ShiroApp> {

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
