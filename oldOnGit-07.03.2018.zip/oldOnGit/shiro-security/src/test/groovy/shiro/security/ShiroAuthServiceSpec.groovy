package shiro.security

import grails.testing.services.ServiceUnitTest
import spock.lang.Specification

class ShiroAuthServiceSpec extends Specification implements ServiceUnitTest<ShiroAuthService>{

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
