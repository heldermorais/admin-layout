package shiro.security

import grails.gorm.services.Service
import grails.gorm.transactions.Transactional


@Transactional
class ShiroAuthService {

    def serviceMethod(){

    }
}
