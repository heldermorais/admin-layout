package shiro.security

class BootStrap {

    def init = { servletContext ->
    }
    def destroy = {
    }
}
