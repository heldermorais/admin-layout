package common.backend

class BootStrap {

    def init = { servletContext ->
    }
    def destroy = {
    }
}
