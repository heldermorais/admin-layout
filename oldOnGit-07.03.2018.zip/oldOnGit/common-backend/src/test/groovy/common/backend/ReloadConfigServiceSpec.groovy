package common.backend

import grails.testing.services.ServiceUnitTest
import spock.lang.Specification

class ReloadConfigServiceSpec extends Specification implements ServiceUnitTest<ReloadConfigService>{

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
