package common.backend

import grails.testing.services.ServiceUnitTest
import spock.lang.Specification

class ActionDescriptionProcessorServiceSpec extends Specification implements ServiceUnitTest<ActionDescriptionProcessorService>{

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
