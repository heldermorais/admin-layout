package common.backend

class Constants {
    public static String LOG_SESSIONID_KEY = "sessionId"
}
