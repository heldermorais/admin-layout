package gui.adminlayout


class AdminLayoutInterceptor {

    boolean before() { true }

    boolean after() { true }

    void afterView() {
        // no-op
    }
}
