package gui.adminlayout

class BootStrap {

    def init = { servletContext ->
    }
    def destroy = {
    }
}
